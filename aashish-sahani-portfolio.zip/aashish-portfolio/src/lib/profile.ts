export const profile = {
  name: "Aashish Sahani",
  shortName: "AASHISH.",
  role: "Graphic Designer · Design Intern",
  location: "Biratnagar, Nepal",
  email: "aashishsahani976@gmail.com",
  phone: "9706987946",
  instagramHandle: "@_aashish_sahani",
  // Verify this destination before launch. Update here if the handle or URL changes.
  instagramUrl: "https://www.instagram.com/_aashish_sahani/",
  // Add a verified PDF at public/resume.pdf and set resumeAvailable to true when ready.
  resumeAvailable: false,
  resumePath: "/resume.pdf",
  education: "Class 12 / +2 · Management stream · BKVM",
  languages: ["Nepali — Fluent", "English — Intermediate", "Hindi — Conversational"],
  availability: "Open to part-time internships while studying",
} as const;
