"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, ArrowUpRight } from "lucide-react";
import { useState } from "react";
const links = [{ href: "/work", label: "Work" }, { href: "/about", label: "About" }, { href: "/resume", label: "Résumé" }, { href: "/contact", label: "Contact" }];
export function SiteHeader() {
  const path = usePathname(); const [open, setOpen] = useState(false);
  return <header className="site-header"><div className="nav-wrap"><Link className="wordmark" href="/" aria-label="Aashish Sahani home">AASHISH<span>.</span></Link><nav className="desktop-nav" aria-label="Main navigation">{links.map((l) => <Link key={l.href} href={l.href} className={path === l.href || (l.href === "/work" && path.startsWith("/work/")) ? "nav-link active" : "nav-link"}>{l.label}</Link>)}</nav><Link className="nav-cta" href="/contact">Let’s talk <ArrowUpRight size={15} aria-hidden="true" /></Link><button className="mobile-menu-button" type="button" aria-label={open ? "Close navigation menu" : "Open navigation menu"} aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)}>{open ? <X size={21} /> : <Menu size={21} />}</button></div>{open && <nav id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation">{links.map((l) => <Link key={l.href} href={l.href} onClick={() => setOpen(false)}>{l.label}<ArrowUpRight size={16} /></Link>)}</nav>}</header>;
}
