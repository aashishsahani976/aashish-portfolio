"use client";
import { useState, type FormEvent } from "react";
import { ArrowUpRight, Mail } from "lucide-react";
import { profile } from "@/lib/profile";
export function ContactForm() {
  const [status, setStatus] = useState("");
  function handleSubmit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); const form = event.currentTarget; if (!form.reportValidity()) return; const data = new FormData(form); const name = String(data.get("name") ?? "").trim(); const email = String(data.get("email") ?? "").trim(); const message = String(data.get("message") ?? "").trim(); const subject = encodeURIComponent(`Portfolio enquiry from ${name}`); const body = encodeURIComponent(`Name: ${name}
Reply email: ${email}

Message:
${message}`); setStatus("Your email app should open with the message prepared. The site has not sent anything yet."); window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`; }
  return <div className="contact-form-wrap"><form className="contact-form" onSubmit={handleSubmit}><div className="form-row"><label>Name<input name="name" autoComplete="name" required minLength={2} maxLength={100} placeholder="Your name" /></label><label>Email<input name="email" type="email" autoComplete="email" required maxLength={254} placeholder="you@example.com" /></label></div><label>Message<textarea name="message" required minLength={10} maxLength={4000} rows={5} placeholder="Tell me a little about the opportunity or project…" /></label><button className="button button-dark form-submit" type="submit">Prepare email <ArrowUpRight size={17} /></button><p className="form-note" aria-live="polite">{status || "This form opens your default email app. It does not send or store your message on this website."}</p></form><div className="email-direct"><span className="mail-icon"><Mail size={18} /></span><span><small>Prefer email?</small><a href={`mailto:${profile.email}`}>{profile.email}</a></span></div></div>;
}
