import type { Metadata } from "next";
import { Reveal } from "@/components/reveal";
import { ProjectCard } from "@/components/project-card";
import { projects } from "@/lib/projects";
export const metadata: Metadata = { title: "Work", description: "Browse design studies and clearly marked portfolio placeholders by Aashish Sahani." };
export default function WorkPage() { return <><section className="page-shell page-hero"><Reveal className="page-heading"><p className="page-kicker">Portfolio / 2026</p><h1>A collection in progress.</h1><p className="lead">A home for promotional graphics, identity explorations, and creative experiments. The cards below are labelled development placeholders—not claims of completed client work.</p></Reveal></section><section className="page-shell" style={{paddingBottom:90}}><p className="work-note">Before publishing: replace each placeholder with an actual project, update the case-study facts, and remove any deliverables you did not create.</p><div className="project-grid">{projects.map((p,i)=><Reveal key={p.slug} delay={i%2*.06}><ProjectCard project={p} index={i}/></Reveal>)}</div></section></>; }
